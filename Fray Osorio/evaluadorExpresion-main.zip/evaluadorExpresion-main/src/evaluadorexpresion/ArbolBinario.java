
package evaluadorexpresion;


public class ArbolBinario {
    
    Nodo raiz;
    
    public ArbolBinario(Nodo raiz){
        this.raiz=raiz;
    }
    
    
    
}
