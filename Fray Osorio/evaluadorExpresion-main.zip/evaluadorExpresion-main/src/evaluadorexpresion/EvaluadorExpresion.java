

package evaluadorexpresion;


public class EvaluadorExpresion {


    public static void main(String[] args) {
        new FrmEvaluadorExpresion().setVisible(true);
    }
    
}
