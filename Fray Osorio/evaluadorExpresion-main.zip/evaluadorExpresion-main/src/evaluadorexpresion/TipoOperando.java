
package evaluadorexpresion;


public enum TipoOperando {
    NINGUNO,
    VARIABLE,
    CONSTANTE
}
