//Creating a class named Edge that stores the edges of the graph  

class Edge {
//the variable source and destination represent the vertices       

    int s, d;
//creating a constructor of the class Edge  

    Edge(int s, int d) {
        this.s = s;
        this.d = d;
    }
}
