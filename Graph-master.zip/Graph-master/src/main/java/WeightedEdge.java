
public class WeightedEdge {

    int s, d, w;
    
    //creating a constructor of the class Edge  

    WeightedEdge(int src, int dest, int weight) {
        this.s = src;
        this.d = dest;
        this.w = weight;
    }
}
